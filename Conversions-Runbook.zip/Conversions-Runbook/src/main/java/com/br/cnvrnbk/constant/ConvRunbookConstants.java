/**
 * 
 */
package com.br.cnvrnbk.constant;

/**
 * Description
 * @author 
 * Created on 22-Jan-2019
 * 
 * Modified on 22-Jan-2019
 * Last Modified by 
 * 
 */
public class ConvRunbookConstants {
	
	/**
	 * Every constant here must be public static final for any data type
	 * 
	 */
	
	public static final String ADMIN ="ADMIN"; 
	public static final String USER ="USER";
	
	
}
