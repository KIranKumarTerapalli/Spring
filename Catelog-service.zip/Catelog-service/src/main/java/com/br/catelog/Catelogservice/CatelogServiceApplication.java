package com.br.catelog.Catelogservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CatelogServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(CatelogServiceApplication.class, args);
	}

}

